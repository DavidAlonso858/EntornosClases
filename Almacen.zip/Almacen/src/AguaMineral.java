import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("85d95cc4-7eb0-45db-90fc-172a113a1e2a")
public class AguaMineral {
    @objid ("790de3d2-bbb0-48c8-8913-ac4d7be38a2a")
    public double precio;

    @objid ("196227cf-881f-42f7-9e06-b91151d4edef")
    public Bebida bebida;

}
