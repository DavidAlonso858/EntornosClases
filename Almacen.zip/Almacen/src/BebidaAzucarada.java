import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b9ca0ac6-d4a9-4465-9683-6641fe9250e7")
public class BebidaAzucarada {
    @objid ("c5a323a3-09e8-4ff5-9937-5197364861f6")
    public double precio;

    @objid ("8b9208fc-6b94-4c97-9058-2837c147e35d")
    public Bebida bebida;

}
