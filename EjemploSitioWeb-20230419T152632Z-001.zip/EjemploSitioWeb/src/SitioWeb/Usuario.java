package SitioWeb;

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("990e6c79-c39b-4c83-9908-8e72faa61f29")
public class Usuario {
    @objid ("c605a670-b2fc-4394-882d-56c545dace84")
    public List<Servidor> servidor = new ArrayList<Servidor> ();

}
