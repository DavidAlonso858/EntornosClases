package SitioWeb;

import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("1bffde14-f1d3-4a69-9d86-c90e5cb7a36e")
public class Acceso {
    @mdl.prop
    @objid ("8581c570-97cf-4c8f-89fa-91cf0a3f065c")
    private String Nombre;

    @mdl.prop
    @objid ("c4e18390-1592-45e4-93d0-e666bcfb90eb")
    private String Contraseña;

}
