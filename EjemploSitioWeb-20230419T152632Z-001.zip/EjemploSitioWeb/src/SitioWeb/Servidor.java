package SitioWeb;

import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6dd4f12a-fc14-439b-b4e2-72b3a10d202d")
public class Servidor {
    @objid ("8b2cd47f-d6a4-4066-b433-74f70fb6cefd")
    public List<Usuario>  = new ArrayList<Usuario> ();

}
