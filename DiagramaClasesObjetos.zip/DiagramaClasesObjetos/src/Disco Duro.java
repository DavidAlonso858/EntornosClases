import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3fddc586-9b11-462d-a186-f982805b8417")
public class Disco Duro {
    @objid ("694f3a77-5d67-400a-b885-2fdb36008d06")
    public List<Extraible >  = new ArrayList<Extraible > ();

}
