import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("bcaac862-7da8-46fa-a98a-88289b8f41e2")
public class Memoria USB {
    @objid ("1facabc9-c11c-47bd-a4e6-c0904ed71c3a")
    public List<Extraible >  = new ArrayList<Extraible > ();

}
