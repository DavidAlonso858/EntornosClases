import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("370ff4a8-cd53-46a4-800a-f4973c34c7e0")
public class Extraible  {
    @objid ("1e13f3d0-53de-46ed-abcd-2daf816baa82")
    public List<Perifericos de almacenamiento>  = new ArrayList<Perifericos de almacenamiento> ();

}
