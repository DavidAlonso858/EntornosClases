import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("713fd556-1e93-4b31-b2d3-5dd61605a964")
public class Elemento {
    @objid ("c4e090a8-340f-46d9-adae-f1772ddf4043")
    public Elemento ;

}
