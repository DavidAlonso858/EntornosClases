import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("b77f39f1-e2cc-405a-85c4-772d3fd891af")
public class Perifericos de almacenamiento {
}
