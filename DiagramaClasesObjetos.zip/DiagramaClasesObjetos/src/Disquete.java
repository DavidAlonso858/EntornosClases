import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("c2d8d3ac-a9c1-4b1a-9403-c63765916a47")
public class Disquete {
    @objid ("d848ddea-32b5-4bd0-8840-2b389fc1794b")
    public List<Extraible >  = new ArrayList<Extraible > ();

}
