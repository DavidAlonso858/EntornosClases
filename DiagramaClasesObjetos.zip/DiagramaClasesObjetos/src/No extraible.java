import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("98822ad4-6496-416b-b416-0fa4a8585638")
public class No extraible {
    @objid ("4fbf8644-4954-4c0e-ab55-16a53a92792f")
    public List<Perifericos de almacenamiento>  = new ArrayList<Perifericos de almacenamiento> ();

}
