import com.modeliosoft.modelio.javadesigner.annotations.mdl;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("0af59793-25a1-4388-a94e-d349a70a2c73")
public class Proceso {
    @mdl.prop
    @objid ("a1b89b34-0e9c-433e-baf7-46df4c12699d")
    private String id;

}
