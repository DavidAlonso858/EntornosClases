import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("c626ee6d-14b0-498b-8d54-ed8f3199b270")
public class Cola {
}
